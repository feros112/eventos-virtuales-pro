'use client'

import { useState, useEffect } from 'react'
import { Map, Compass, MessageCircle, LogOut } from 'lucide-react'
import Link from 'next/link'

interface LobbyHudProps {
    onOpenFloorPlan?: () => void;
    onOpenChat?: () => void;
    onSignOut?: () => void;
}

export default function LobbyHud({ onOpenFloorPlan, onOpenChat, onSignOut }: LobbyHudProps) {
    const [currentTime, setCurrentTime] = useState('');

    useEffect(() => {
        const updateTime = () => {
            const now = new Date();
            setCurrentTime(now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }));
        };
        updateTime();
        const interval = setInterval(updateTime, 1000);
        return () => clearInterval(interval);
    }, []);

    const navButtonStyle = {
        background: 'none',
        border: 'none',
        padding: '0.5rem 1rem',
        color: '#000',
        fontSize: '0.9rem',
        fontWeight: 700,
        cursor: 'pointer',
        display: 'flex',
        alignItems: 'center',
        gap: '0.5rem',
        textTransform: 'capitalize' as const,
        transition: 'opacity 0.2s',
    };

    const bottomNavStyle = {
        background: 'none',
        border: 'none',
        padding: '0.5rem 1rem',
        color: '#000',
        fontSize: '0.85rem',
        fontWeight: 700,
        cursor: 'pointer',
        display: 'flex',
        alignItems: 'center',
        gap: '0.5rem',
        transition: 'opacity 0.2s',
    }

    return (
        <div style={{ position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column', justifyContent: 'space-between', pointerEvents: 'none', fontFamily: 'Inter, sans-serif' }}>
            <div style={{ height: '80px', backgroundColor: 'rgba(255, 255, 255, 0.95)', display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '0 2.5rem', pointerEvents: 'auto', boxShadow: '0 2px 10px rgba(0,0,0,0.05)' }}>
                <Link href="/" style={{ textDecoration: 'none', display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
                    <div style={{ fontSize: '1.6rem', fontWeight: 900, color: '#000', letterSpacing: '-0.05em', textTransform: 'uppercase' }}>
                        EXPO EVENTOS <span style={{ color: '#4f46e5' }}>360 PRO</span>
                    </div>
                </Link>
                <div style={{ display: 'flex', alignItems: 'center', gap: '1.5rem' }}>
                    <button style={navButtonStyle}>Agenda</button>
                    <button style={navButtonStyle}>Profile</button>
                    <button onClick={onSignOut} style={{ ...navButtonStyle, display: 'flex', alignItems: 'center', gap: '0.4rem' }}>Logout</button>
                </div>
            </div>
            <div style={{ height: '70px', backgroundColor: 'rgba(255, 255, 255, 0.95)', display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '0 2.5rem', pointerEvents: 'auto', boxShadow: '0 -2px 10px rgba(0,0,0,0.05)' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '2rem' }}>
                    <button style={bottomNavStyle}><Compass size={20} color="#06b6d4" />Quick Nav</button>
                    <button onClick={onOpenFloorPlan} style={bottomNavStyle}><Map size={20} color="#06b6d4" />Floor Plan</button>
                </div>
                <Link href="/" style={{ textDecoration: 'none', display: 'flex', alignItems: 'center', gap: '0.1rem' }}>
                    <span style={{ fontSize: '1.4rem', fontWeight: 900, color: '#000', letterSpacing: '-0.02em', textTransform: 'uppercase' }}>
                        Eventos Virtuales <span style={{ color: '#4f46e5' }}>Pro</span>
                    </span>
                </Link>
                <button onClick={onOpenChat} style={{ ...bottomNavStyle, background: 'none', border: 'none', color: '#000', fontSize: '1rem', fontWeight: 700, display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                    Chat <MessageCircle size={24} color="#06b6d4" />
                </button>
            </div>
            <style jsx>{` button:hover { opacity: 0.7; } `}</style>
        </div>
    )
}
